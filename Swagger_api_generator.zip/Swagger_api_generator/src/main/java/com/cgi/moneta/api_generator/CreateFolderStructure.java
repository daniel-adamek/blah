package com.cgi.moneta.api_generator;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.ws.commons.util.NamespaceContextImpl;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;



public class CreateFolderStructure {

	public void createFolderStructure(File dir) {
		File[] directoryListing = dir.listFiles();
		// nacitam ze slozky swaggery a beru jejich nazvy
		if (directoryListing != null) {
		for (File child : directoryListing) {
				// vytahni z nazvu api name a verzi
				String name = child.getName();
				// vytvor adresare
				new File("..\\interface_swagger_generator\\apis\\" + name + "\\" + name + "001" + "\\src").mkdirs();
				// https://dom4j.github.io/
				
			}
		}
	}
	
//	public void editPomFile(Document doc) {
//		List<Node> list = doc.selectNodes("/pom:project/pom:groupId");
//		System.out.println(list.size());
//		for (Iterator<Node> iter = list.iterator(); iter.hasNext();) {
//			Attribute atr = (Attribute) iter.next();
//			String value = atr.getValue();
//			System.out.println("Ahoj");
//			System.out.println(value);
//		}
//	}
	
	public void parse(File file) {
		DocumentBuilderFactory domFactory = DocumentBuilderFactory
		        .newInstance();
		domFactory.setNamespaceAware(true);

		DocumentBuilder builder = domFactory.newDocumentBuilder();
		Document doc = builder.parse("C:\\Users\\daniel.adamek\\Desktop\\PARSE\\pom.xml");
		XPath xpath = XPathFactory.newInstance().newXPath();
		Map<String, String> namespaces = new HashMap<String, String>();
		namespaces.put("pom", "http://maven.apache.org/POM/4.0.0");

		MapBase
		xpath.setNamespaceContext(
		        new MapBase("http://maven.apache.org/POM/4.0.0", 
		                namespaces));

		XPathExpression expr = xpath.compile("/pom:project/pom:version");
		Object result = expr.evaluate(doc, XPathConstants.NODESET);
		NodeList nodes = (NodeList) result;
		for (int i = 0; i < nodes.getLength(); i++) {
		    System.out.println(nodes.item(i).getTextContent());
		}
	}

}
