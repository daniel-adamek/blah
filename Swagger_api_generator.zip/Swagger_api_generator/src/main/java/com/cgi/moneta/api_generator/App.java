package com.cgi.moneta.api_generator;

import java.io.File;

import org.dom4j.DocumentException;

public class App {

	public static void main(String[] args) {
		//nactu properties file kde budou cesty
		
		CreateFolderStructure createFolderStructure = new CreateFolderStructure();
		
		File file = new File("C:\\Users\\daniel.adamek\\Desktop\\PARSE\\pom.xml");
		try {
			createFolderStructure.editPomFile(createFolderStructure.parse(file));
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
