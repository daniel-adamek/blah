package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerParameter {

    private String $ref;

    public String get$ref() {
        return $ref;
    }
}