package com.cgi.moneta.interface_swagger_generator.swagger_model;

public class SwaggerContact {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
