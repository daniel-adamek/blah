package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonInclude;


import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerProperty {

    private String $ref;
    private String type;
    private String format;
    private String description;
    private Integer minLength;
    private Integer maxLength;
    private String pattern;
    private SwaggerProperty items;
    private Map<String, SwaggerProperty> properties;
    private List<?> enums;
    //private List<String> required = null;

    public void createProperties() {
        properties = new LinkedHashMap<>();
    }


    public SwaggerProperty getItems() {
        return items;
    }

    public void setItems(SwaggerProperty items) {
        this.items = items;
    }

    public Map<String, SwaggerProperty> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, SwaggerProperty> properties) {
        this.properties = properties;
    }

	public void setType(String type) {
		if (type.equals("datetime") || type.equals("generalizedtime") || type.equals("date")) {
			this.type = "string";
			if (type.equals("datetime") || type.equals("generalizedtime")) {
				setFormat("date-time");
			} else {
				setFormat("date");
			}
		} else if (type.equals("decimal") || type.equals("float")) {
			this.type = "number";
		} else {
			this.type = type;
		}
	}


    public void setFormat(String format) {
        this.format = format;
    }

    public String getFormat() {
        return format;
    }

    public String getType() {
        return type;
    }

    public String get$ref() {
        return $ref;
    }

    public SwaggerProperty set$ref(String $ref) {
        this.$ref = $ref;
        return this;
    }
  
    public String getDescription() {
        return description;
    }
  
    public void setDescription(String description) {
        this.description = description;
    }



    public void setMaxLength(Integer maxLength) {
        this.maxLength = maxLength;
    }

    public Integer getMaxLength() {
        return maxLength;
    }
    
    public List<?> getEnums() {
        return enums;
    }

    public void setEnums(List<?> enums) {
        this.enums = enums;
    }

    public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public Integer getMinLength() {
		return minLength;
	}

	public void setMinLength(Integer minLength) {
		this.minLength = minLength;
	}
}