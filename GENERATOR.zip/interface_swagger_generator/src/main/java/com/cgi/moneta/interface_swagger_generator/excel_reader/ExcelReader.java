package com.cgi.moneta.interface_swagger_generator.excel_reader;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;


public class ExcelReader {
	// all sheets with interfaces
    List<SheetEntity> properties;


    public List<SheetEntity> getAllInterfacesFromExcel(String path) throws IOException, InvalidFormatException {
        properties = new ArrayList<SheetEntity>();
        Workbook workbook = WorkbookFactory.create(new File(path));
		readSheet(workbook.getSheetAt(0));
        workbook.close();

        return properties;
    }

    private void readSheet(Sheet sheet) {
        // Create a DataFormatter to format and get each cell's value as String
        DataFormatter dataFormatter = new DataFormatter();

        Iterator<Row> rowIterator = sheet.rowIterator();

        rowIterator.next();

        while (rowIterator.hasNext()) {
            SheetEntity sheetEntity = new SheetEntity();
            properties.add(sheetEntity);
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();

            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if (!cellValue.isEmpty()) {
                    setEntityProperty(sheet.getSheetName(), sheetEntity, cell.getColumnIndex(), cellValue.trim());
                }
            }

        }
    }

    private void setEntityProperty(String sheetName, SheetEntity sheetEntity, int cellNumber, String value) {
        switch (cellNumber) {
            case 0:
                sheetEntity.setOrder(value);
                break;
            case 1:
                sheetEntity.setName(value);
                break;
            case 2:
                sheetEntity.setDirection(value);
                break;
            case 3:
                if(value != null && value.contains("Hcele")) {
                    sheetEntity.setType("integer");
                }
                if(value != null && value.contains("Hretezec")) {
                    sheetEntity.setType("string");
                }
                break;
            case 4:
                sheetEntity.setDescription(value);
                break;

        }
    }

}
