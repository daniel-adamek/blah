package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.models.ExternalDocs;
import io.swagger.models.Scheme;
import io.swagger.models.SecurityRequirement;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerOperation {
    private List<String> tags;
    private String summary;
    private String operationId;
    private String description; 
    private List<Scheme> schemes;
    private List<String> consumes;
    private List<String> produces;
    private List<SwaggerBodyParameter> parameters = new ArrayList<SwaggerBodyParameter>();
    private Map<String, SwaggerResponse> responses;
    private List<Map<String, List<String>>> security;
    private ExternalDocs externalDocs;
    private Boolean deprecated;

    public SwaggerOperation summary(String summary) {
        this.setSummary(summary);
        return this;
    }

    public SwaggerOperation description(String description) {
        this.setDescription(description);
        return this;
    }

    public SwaggerOperation operationId(String operationId) {
        this.setOperationId(operationId);
        return this;
    }

    public SwaggerOperation schemes(List<Scheme> schemes) {
        this.setSchemes(schemes);
        return this;
    }

    public SwaggerOperation scheme(Scheme scheme) {
        this.addScheme(scheme);
        return this;
    }

    public SwaggerOperation consumes(List<String> consumes) {
        this.setConsumes(consumes);
        return this;
    }

    public SwaggerOperation consumes(String consumes) {
        this.addConsumes(consumes);
        return this;
    }

    public SwaggerOperation produces(List<String> produces) {
        this.setProduces(produces);
        return this;
    }

    public SwaggerOperation produces(String produces) {
        this.addProduces(produces);
        return this;
    }

    public SwaggerOperation security(SecurityRequirement security) {
        this.addSecurity(security.getName(), security.getScopes());
        return this;
    }

    public SwaggerOperation parameter(SwaggerBodyParameter parameter) {
        this.addParameter(parameter);
        return this;
    }

    public SwaggerOperation response(int key, SwaggerResponse response) {
        this.addResponse(String.valueOf(key), response);
        return this;
    }

    public SwaggerOperation defaultResponse(SwaggerResponse response) {
        this.addResponse("default", response);
        return this;
    }

    public SwaggerOperation tags(List<String> tags) {
        this.setTags(tags);
        return this;
    }

    public SwaggerOperation tag(String tag) {
        this.addTag(tag);
        return this;
    }

    public SwaggerOperation externalDocs(ExternalDocs externalDocs) {
        this.setExternalDocs(externalDocs);
        return this;
    }

    public SwaggerOperation deprecated(Boolean deprecated) {
        this.setDeprecated(deprecated);
        return this;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public void addTag(String tag) {
        if (this.tags == null) {
            this.tags = new ArrayList<String>();
        }
        this.tags.add(tag);
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    public List<Scheme> getSchemes() {
        return schemes;
    }

    public void setSchemes(List<Scheme> schemes) {
        this.schemes = schemes;
    }

    public void addScheme(Scheme scheme) {
        if (schemes == null) {
            schemes = new ArrayList<Scheme>();
        }
        if (!schemes.contains(scheme)) {
            schemes.add(scheme);
        }
    }

    public List<String> getConsumes() {
        return consumes;
    }

    public void setConsumes(List<String> consumes) {
        this.consumes = consumes;
    }

    public void addConsumes(String consumes) {
        if (this.consumes == null) {
            this.consumes = new ArrayList<String>();
        }
        this.consumes.add(consumes);
    }

    public List<String> getProduces() {
        return produces;
    }

    public void setProduces(List<String> produces) {
        this.produces = produces;
    }

    public void addProduces(String produces) {
        if (this.produces == null) {
            this.produces = new ArrayList<String>();
        }
        this.produces.add(produces);
    }

    public List<SwaggerBodyParameter> getParameters() {
        return parameters;
    }

    public void setParameters(List<SwaggerBodyParameter> parameters) {
        this.parameters = parameters;
    }

    public void addParameter(SwaggerBodyParameter parameter) {
        if (this.parameters == null) {
            this.parameters = new ArrayList<SwaggerBodyParameter>();
        }
        this.parameters.add(parameter);
    }

    public Map<String, SwaggerResponse> getResponses() {
        return responses;
    }

    public void setResponses(Map<String, SwaggerResponse> responses) {
        this.responses = responses;
    }

    public void addResponse(String key, SwaggerResponse response) {
        if (this.responses == null) {
            this.responses = new LinkedHashMap<String, SwaggerResponse>();
        }
        this.responses.put(key, response);
    }

    public List<Map<String, List<String>>> getSecurity() {
        return security;
    }

    public void setSecurity(List<Map<String, List<String>>> security) {
        this.security = security;
    }

    public void addSecurity(String name, List<String> scopes) {
        if (this.security == null) {
            this.security = new ArrayList<Map<String, List<String>>>();
        }
        Map<String, List<String>> req = new LinkedHashMap<String, List<String>>();
        if (scopes == null) {
            scopes = new ArrayList<String>();
        }
        req.put(name, scopes);
        this.security.add(req);
    }

    public ExternalDocs getExternalDocs() {
        return externalDocs;
    }

    public void setExternalDocs(ExternalDocs value) {
        this.externalDocs = value;
    }

    public Boolean isDeprecated() {
        return deprecated;
    }

    public void setDeprecated(Boolean value) {
        this.deprecated = value;
    }

    @Override
    public String toString() {
        return super.toString() + "[" + operationId + "]";
    }
}
