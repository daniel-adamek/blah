package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerResponseSchema {
	
    private String $ref;
    private String type;
    private Map<String, SwaggerProperty> properties;


    public String get$ref() {
        return $ref;
    }

    public SwaggerResponseSchema set$ref(String $ref) {
        this.$ref = $ref;
        return this;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Map<String, SwaggerProperty> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, SwaggerProperty> properties) {
        this.properties = properties;
    }
}