package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.LinkedHashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerBodyParameter {
	private String name;
	private String in;
	private String description;
	private boolean required;
	private SwaggerResponseSchema schema;
	private Map<String, String> examples;

    public SwaggerBodyParameter() {
    	setIn("body");
    }

    public SwaggerBodyParameter schema(SwaggerResponseSchema schema) {
        this.setSchema(schema);
        return this;
    }

    public SwaggerBodyParameter example(String mediaType, String value) {
        this.addExample(mediaType, value);
        return this;
    }

    public SwaggerBodyParameter description(String description) {
        this.setDescription(description);
        return this;
    }

    public SwaggerBodyParameter name(String name) {
        this.setName(name);
        return this;
    }

    public SwaggerResponseSchema getSchema() {
        return schema;
    }

    public void setSchema(SwaggerResponseSchema schema) {
        this.schema = schema;
    }
	
	public String getIn() {
		return in;
	}

	public void setIn(String in) {
		this.in = in;
	}

    public void addExample(String mediaType, String value) {
        if(examples == null) {
            examples = new LinkedHashMap<String, String>();
        }
        examples.put(mediaType, value);
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}
}
