package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerResponse {

	private String description;
    private SwaggerResponseSchema schema;

    public SwaggerResponseSchema getSchema() {
        return schema;
    }

    public void setSchema(SwaggerResponseSchema model) {
        this.schema = model;
    }


    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return description;
    }
}