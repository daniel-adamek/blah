package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerModelWrapper {

    private String type;
    private String description;
    private Map<String, SwaggerProperty> properties;
    private List<String> required = null;
    
    public void createProperties(){
        this.properties = new LinkedHashMap<>();
    }

    public SwaggerModelWrapper() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return null;
    }

    public void setTitle(String s) {

    }

    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }

    public Map<String, SwaggerProperty> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, SwaggerProperty> properties) {
        this.properties = properties;
    }
    
    public List<String> getRequired() {
        if(required == null)
        {
            required = new ArrayList<>();
        }
        return required;
    }

    public void setRequired(List<String> required) {
        this.required = required;
    }
}