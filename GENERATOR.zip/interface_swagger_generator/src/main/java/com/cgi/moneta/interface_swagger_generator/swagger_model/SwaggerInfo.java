package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.models.Contact;
import io.swagger.models.License;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerInfo {
    private String version;
    private String title;
    private String description;
    private String termsOfService;
    private SwaggerContact contact;
    private License license;


    public SwaggerInfo version(String version) {
        this.setVersion(version);
        return this;
    }

    public SwaggerInfo title(String title) {
        this.setTitle(title);
        return this;
    }

    public SwaggerInfo description(String description) {
        this.setDescription(description);
        return this;
    }

    public SwaggerInfo termsOfService(String termsOfService) {
        this.setTermsOfService(termsOfService);
        return this;
    }

    public SwaggerInfo contact(SwaggerContact contact) {
        this.setContact(contact);
        return this;
    }

    public SwaggerInfo license(License license) {
        this.setLicense(license);
        return this;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTermsOfService() {
        return termsOfService;
    }

    public void setTermsOfService(String termsOfService) {
        this.termsOfService = termsOfService;
    }

    public SwaggerContact getContact() {
        return contact;
    }

    public void setContact(SwaggerContact contact) {
        this.contact = contact;
    }

    public License getLicense() {
        return license;
    }

    public void setLicense(License license) {
        this.license = license;
    }
}
