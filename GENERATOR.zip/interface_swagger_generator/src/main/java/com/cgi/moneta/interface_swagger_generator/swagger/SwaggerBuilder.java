package com.cgi.moneta.interface_swagger_generator.swagger;


import com.cgi.moneta.interface_swagger_generator.App;
import com.cgi.moneta.interface_swagger_generator.excel_reader.SheetEntity;

import com.cgi.moneta.interface_swagger_generator.swagger_model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;


import java.io.File;
import java.io.IOException;
import java.util.*;

public class SwaggerBuilder {

    private static final String VERSION = "v1";
    private static final String FILE_EXTENSION = ".yaml";

    private static final String APPLICATION_JSON = "application/json";
    private static final String APPLICATION_XML = "application/xml";
    private static final String TEXT_XML = "text/xml";
    private static final String TEXT_HTML = "text/html";


    public void writeSwaggerSchemas(List<SheetEntity> entities, String output_path) throws IOException {
        writeSwaggerSchema(entities, output_path);
    }

    private void writeSwaggerToJson(SwaggerWrapper swagger, String output_path) throws IOException {
        String path = output_path;

        // Create an ObjectMapper mapper for YAML
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        mapper.writeValue(new File(path), swagger);
    }


    private void writeSwaggerSchema(List<SheetEntity> entities, String output_path) throws IOException {
        SwaggerWrapper swagger = new SwaggerWrapper();
        prepareSwagger(swagger, entities);
        setDefinitionsToSwagger(swagger);
        setXTifToSwagger(swagger);
        writeSwaggerToJson(swagger, output_path + "swagger" + FILE_EXTENSION);
    }

    private SwaggerWrapper prepareSwagger(SwaggerWrapper swagger, List<SheetEntity> entities) {
        setPropertiesToSwagger(swagger);
        setPathsToSwagger(entities, swagger);

        SwaggerModelWrapper swaggerModelWrapper = new SwaggerModelWrapper();
        swaggerModelWrapper.setType("object");

        Map<String, SwaggerProperty> properties = new LinkedHashMap<>();
        SwaggerProperty swaggerProperty = new SwaggerProperty();
        String requestDefition = "#/definitions/request";
        swaggerProperty.set$ref(requestDefition);
        properties.put("request", swaggerProperty);

        return swagger;
    }

    private void setDefinitionsToSwagger(SwaggerWrapper swagger) {
        SwaggerModelWrapper swaggerModelWrapper = new SwaggerModelWrapper();
        swaggerModelWrapper.setType("object");
        swaggerModelWrapper.createProperties();
        Map<String, SwaggerProperty> swaggerProperties = new HashMap<>();
        SwaggerProperty swaggerProperty = new SwaggerProperty();
        swaggerProperty.setType("string");
        swaggerProperties.put("resultCode", swaggerProperty);
        swaggerProperties.put("errorCode", swaggerProperty);
        swaggerProperties.put("errorDesc", swaggerProperty);
        swaggerModelWrapper.setProperties(swaggerProperties);
        List<String> requiered = new ArrayList<>();
        requiered.add("resultCode");
        requiered.add("errorCode");
        requiered.add("errorDesc");
        swaggerModelWrapper.setRequired(requiered);
        swagger.addDefinition("ErrorModel", swaggerModelWrapper);
    }

    private void setXTifToSwagger(SwaggerWrapper swagger) {
        Map<String, String> xTifMap = new LinkedHashMap<>();
        xTifMap.put("application", App.properties.getProperty("APPLICATION_NAME"));
        xTifMap.put("apiName", App.properties.getProperty("API_NAME"));
        xTifMap.put("apiVersion", "001");
        xTifMap.put("messageType", "XML");
        xTifMap.put("messageVersion", "2");
        xTifMap.put("operationType", "active");
        swagger.setxTif(xTifMap);
    }

    private void setPropertiesToSwagger(SwaggerWrapper swagger) {
        SwaggerInfo swaggerInfo = new SwaggerInfo();
        swaggerInfo.setVersion(VERSION);
        swaggerInfo.setDescription(App.properties.getProperty("DESCRIPTION"));
        swaggerInfo.setTitle(App.properties.getProperty("TITLE"));
        swaggerInfo.setTermsOfService("http://swagger.io/terms/");
        SwaggerContact contact = new SwaggerContact();
        contact.setName("Swagger API team");
        swaggerInfo.setContact(contact);

        swagger.setBasePath(App.properties.getProperty("BASE_PATH"));

        swagger.setInfo(swaggerInfo);
        swagger.setSchemes(new ArrayList<>());
        swagger.setConsumes(new ArrayList<>());
        swagger.setProduces(new ArrayList<>());
        swagger.addScheme("https");
        swagger.getConsumes().add(APPLICATION_JSON);
        swagger.getConsumes().add(APPLICATION_XML);
        swagger.getProduces().add(APPLICATION_JSON);
        swagger.getProduces().add(APPLICATION_XML);

    }

    private void setPathsToSwagger(List<SheetEntity> entities, SwaggerWrapper swagger) {
        Map<String, SwaggerPath> paths = new LinkedHashMap<>();

        SwaggerOperation post = new SwaggerOperation();
        List<SwaggerBodyParameter> parameters = new ArrayList<>();
        SwaggerBodyParameter operationParam = new SwaggerBodyParameter();
        operationParam.setIn("body");
        operationParam.setName("input");
        SwaggerResponseSchema swaggerResponseSchema = new SwaggerResponseSchema();
        swaggerResponseSchema.setType("object");
        Map<String, SwaggerProperty> swaggerProperties = new LinkedHashMap<>();
        for (SheetEntity sheetEntity : entities) {
            if (sheetEntity.getDirection().contains("In")) {
                SwaggerProperty swaggerProperty = new SwaggerProperty();
                swaggerProperty.setType(sheetEntity.getType());
                swaggerProperty.setDescription(sheetEntity.getDescription());
                swaggerProperties.put(sheetEntity.getName(), swaggerProperty);
            }
        }
        swaggerResponseSchema.setProperties(swaggerProperties);
        operationParam.setSchema(swaggerResponseSchema);
        operationParam.setRequired(true);

        parameters.add(operationParam);

        Map<String, SwaggerResponse> responses = new LinkedHashMap<>();

        SwaggerResponse swaggerResponse200 = new SwaggerResponse();
        swaggerResponse200.setDescription("OK");
        SwaggerResponseSchema swagger200schema = new SwaggerResponseSchema();
        swagger200schema.setType("object");
        Map<String, SwaggerProperty> swagger200SchemaProperties = new LinkedHashMap<>();
        for (SheetEntity sheetEntity : entities) {
            if (sheetEntity.getDirection().contains("Out")) {
                SwaggerProperty swaggerProperty = new SwaggerProperty();
                swaggerProperty.setType(sheetEntity.getType());
                swagger200SchemaProperties.put(sheetEntity.getName(), swaggerProperty);
            }
        }
        SwaggerProperty swagger200SchemaProperty = new SwaggerProperty();
        swagger200SchemaProperty.set$ref("#/definitions/ErrorModel");
        swagger200SchemaProperties.put("tifResponseStatus", swagger200SchemaProperty);
        swagger200schema.setProperties(swagger200SchemaProperties);
        swaggerResponse200.setSchema(swagger200schema);


        SwaggerResponse swaggerResponseDefault = new SwaggerResponse();
        swaggerResponseDefault.setDescription("unexpected error");
        SwaggerResponseSchema swaggerDefaultSchema = new SwaggerResponseSchema();
        swaggerDefaultSchema.setType("object");
        Map<String, SwaggerProperty> swaggerDefaultSchemaProperties = new LinkedHashMap<>();
        SwaggerProperty swaggerDefaultSchemaProperty = new SwaggerProperty();
        swaggerDefaultSchemaProperty.set$ref("#/definitions/ErrorModel");
        swaggerDefaultSchemaProperties.put("tifResponseStatus", swaggerDefaultSchemaProperty);
        swaggerDefaultSchema.setProperties(swaggerDefaultSchemaProperties);
        swaggerResponseDefault.setSchema(swaggerDefaultSchema);

        responses.put("200", swaggerResponse200);
        responses.put("default", swaggerResponseDefault);

//        responses.put("200", new SwaggerResponse().description("OK").responseSchema(new SwaggerResponseSchema().set$ref(responseRef)));
//        responses.put("default", new SwaggerResponse().description("unexpected error").responseSchema(new SwaggerResponseSchema().set$ref(responseRef)));


        post.setResponses(responses);
        post.setParameters(parameters);
        post.setProduces(new ArrayList<>());
        post.getProduces().add(APPLICATION_JSON);
        post.getProduces().add(APPLICATION_XML);
        post.getProduces().add(TEXT_XML);
        post.getProduces().add(TEXT_HTML);

        SwaggerPath path = new SwaggerPath();
        path.setPost(post);
        paths.put("/", path);
        swagger.setPaths(paths);
    }

}