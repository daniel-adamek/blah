package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.models.Response;
import io.swagger.models.SecurityRequirement;
import io.swagger.models.Tag;
import io.swagger.models.parameters.Parameter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerWrapper {
    protected String swagger = "2.0";
    protected SwaggerInfo info;
    protected String host;
    protected String basePath;
    protected List<Tag> tags;
    protected List<String> schemes;
    protected List<String> consumes;
    protected List<String> produces;
    protected Map<String, SwaggerSecuritySchemeDefinition> securityDefinitions;
    protected List<Map<String, List<String>>> security;
    protected Map<String, SwaggerPath> paths;
    protected Map<String, SwaggerModelWrapper> definitions;
    protected Map<String, Parameter> parameters;
    protected Map<String, Response> responses;
    @JsonProperty("x-tif")
    protected Map<String, String> xTif;


    // getter & setters
    public String getSwagger() {
        return swagger;
    }

    public void setSwagger(String swagger) {
        this.swagger = swagger;
    }

    public SwaggerInfo getInfo() {
        return info;
    }

    public void setInfo(SwaggerInfo info) {
        this.info = info;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getBasePath() {
        return basePath;
    }

    public void setBasePath(String basePath) {
        this.basePath = basePath;
    }

    public List<String> getSchemes() {
        return schemes;
    }

    public void setSchemes(List<String> schemes) {
        this.schemes = schemes;
    }

    public void addScheme(String scheme) {
        if (schemes == null) {
            schemes = new ArrayList<String>();
        }
        if (!schemes.contains(scheme)) {
            schemes.add(scheme);
        }
    }

    public List<Tag> getTags() {
        return tags;
    }

    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

    public Tag getTag(String tagName) {
	Tag tag = null;
	if (this.tags != null && tagName != null) {
	    for (Tag existing : this.tags) {
		if (existing.getName().equals(tagName)) {
		    tag = existing;
		    break;
		}
	    }
	}
	return tag;
    }
    
    public void addTag(Tag tag) {
        if (this.tags == null) {
            this.tags = new ArrayList<Tag>();
        }
        if (tag != null && tag.getName() != null) {
            if (getTag(tag.getName()) == null) {
        	this.tags.add(tag);
            }
        }
    }

    public List<String> getConsumes() {
        return consumes;
    }

    public void setConsumes(List<String> consumes) {
        this.consumes = consumes;
    }

    public void addConsumes(String consumes) {
        if (this.consumes == null) {
            this.consumes = new ArrayList<String>();
        }

        if (!this.consumes.contains(consumes)) {
            this.consumes.add(consumes);
        }
    }

    public List<String> getProduces() {
        return produces;
    }

    public void setProduces(List<String> produces) {
        this.produces = produces;
    }

    public void addProduces(String produces) {
        if (this.produces == null) {
            this.produces = new ArrayList<String>();
        }

        if (!this.produces.contains(produces)) {
            this.produces.add(produces);
        }
    }

    public Map<String, SwaggerPath> getPaths() {
        return paths;
    }

    public void setPaths(Map<String, SwaggerPath> paths) {
        this.paths = paths;
    }

    public SwaggerPath getPath(String path) {
        if (this.paths == null) {
            return null;
        }
        return this.paths.get(path);
    }

    public Map<String, SwaggerSecuritySchemeDefinition> getSecurityDefinitions() {
        return securityDefinitions;
    }

    public void setSecurityDefinitions(Map<String, SwaggerSecuritySchemeDefinition> securityDefinitions) {
        this.securityDefinitions = securityDefinitions;
    }

    public void addSecurityDefinition(String name, SwaggerSecuritySchemeDefinition securityDefinition) {
        if (this.securityDefinitions == null) {
            this.securityDefinitions = new LinkedHashMap<String, SwaggerSecuritySchemeDefinition>();
        }
        this.securityDefinitions.put(name, securityDefinition);
    }

    /**
     * @deprecated Use {@link #getSecurity()}.
     */
    @JsonIgnore
    @Deprecated
    public List<Map<String, List<String>>> getSecurityRequirement() {
        return security;
    }

    /**
     * @deprecated Use {@link #setSecurity(List)}.
     */
    @JsonIgnore
    @Deprecated
    public void setSecurityRequirement(List<Map<String, List<String>>> securityRequirements) {
        this.security = securityRequirements;
    }

    /**
     * @deprecated Use {@link #addSecurity(SecurityRequirement)}.
     */
    @JsonIgnore
    @Deprecated
    public void addSecurityDefinition(Map<String, List<String>> securityRequirement) {
        this.addSecurity(securityRequirement);
    }

    public List<Map<String, List<String>>> getSecurity() {
        return security;
    }

    public void setSecurity(List<Map<String, List<String>>> securityRequirements) {
        this.security = securityRequirements;
    }

    public void addSecurity(Map<String, List<String>> securityRequirement) {
        if (this.security == null) {
            this.security = new ArrayList<Map<String, List<String>>>();
        }
        this.security.add(securityRequirement);
    }

    public Map<String, SwaggerModelWrapper> getDefinitions() {
        return definitions;
    }

    public void setDefinitions(Map<String, SwaggerModelWrapper> definitions) {
        this.definitions = definitions;
    }

    public void addDefinition(String key, SwaggerModelWrapper model) {
        if (this.definitions == null) {
            this.definitions = new LinkedHashMap<String, SwaggerModelWrapper>();
        }
        this.definitions.put(key, model);
    }

    public Map<String, Parameter> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Parameter> parameters) {
        this.parameters = parameters;
    }

    public Parameter getParameter(String parameter) {
        if (this.parameters == null) {
            return null;
        }
        return this.parameters.get(parameter);
    }

    public void addParameter(String key, Parameter parameter) {
        if (this.parameters == null) {
            this.parameters = new LinkedHashMap<String, Parameter>();
        }
        this.parameters.put(key, parameter);
    }

    public Map<String, Response> getResponses() {
        return responses;
    }

    public void setResponses(Map<String, Response> responses) {
        this.responses = responses;
    }

    @JsonProperty("x-tif")
    public Map<String, String> getxTif() {
        return xTif;
    }

    public void setxTif(Map<String, String> xTif) {
        this.xTif = xTif;
    }
}