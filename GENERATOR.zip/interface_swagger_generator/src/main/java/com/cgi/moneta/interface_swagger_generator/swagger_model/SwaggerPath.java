package com.cgi.moneta.interface_swagger_generator.swagger_model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.models.HttpMethod;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@JsonPropertyOrder({"get", "head", "post", "put", "delete", "options", "patch"})
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SwaggerPath {

    private SwaggerOperation get;
    private SwaggerOperation put;
    private SwaggerOperation post;
    private SwaggerOperation head;
    private SwaggerOperation delete;
    private SwaggerOperation patch;
    private SwaggerOperation options;
    private List<SwaggerParameter> parameters;

    public SwaggerPath set(String method, SwaggerOperation op) {
        if ("get".equals(method)) {
            return get(op);
        }
        if ("put".equals(method)) {
            return put(op);
        }
        if ("head".equals(method)) {
            return head(op);
        }
        if ("post".equals(method)) {
            return post(op);
        }
        if ("delete".equals(method)) {
            return delete(op);
        }
        if ("patch".equals(method)) {
            return patch(op);
        }
        if ("options".equals(method)) {
            return options(op);
        }
        return null;
    }

    public SwaggerPath get(SwaggerOperation get) {
        this.get = get;
        return this;
    }

    public SwaggerPath head(SwaggerOperation head) {
        this.head = head;
        return this;
    }

    public SwaggerPath put(SwaggerOperation put) {
        this.put = put;
        return this;
    }

    public SwaggerPath post(SwaggerOperation post) {
        this.post = post;
        return this;
    }

    public SwaggerPath delete(SwaggerOperation delete) {
        this.delete = delete;
        return this;
    }

    public SwaggerPath patch(SwaggerOperation patch) {
        this.patch = patch;
        return this;
    }

    public SwaggerPath options(SwaggerOperation options) {
        this.options = options;
        return this;
    }

    public SwaggerOperation getGet() {
        return get;
    }

    public void setGet(SwaggerOperation get) {
        this.get = get;
    }

    public SwaggerOperation getHead() {
        return head;
    }

    public void setHead(SwaggerOperation head) {
        this.head = head;
    }

    public SwaggerOperation getPut() {
        return put;
    }

    public void setPut(SwaggerOperation put) {
        this.put = put;
    }

    public SwaggerOperation getPost() {
        return post;
    }

    public void setPost(SwaggerOperation post) {
        this.post = post;
    }

    public SwaggerOperation getDelete() {
        return delete;
    }

    public void setDelete(SwaggerOperation delete) {
        this.delete = delete;
    }

    public SwaggerOperation getPatch() {
        return patch;
    }

    public void setPatch(SwaggerOperation patch) {
        this.patch = patch;
    }

    public SwaggerOperation getOptions() {
        return options;
    }

    public void setOptions(SwaggerOperation options) {
        this.options = options;
    }

    @JsonIgnore
    public List<SwaggerOperation> getOperations() {
        List<SwaggerOperation> allOperations = new ArrayList<SwaggerOperation>();
        if (get != null) {
            allOperations.add(get);
        }
        if (put != null) {
            allOperations.add(put);
        }
        if (head != null) {
            allOperations.add(head);
        }
        if (post != null) {
            allOperations.add(post);
        }
        if (delete != null) {
            allOperations.add(delete);
        }
        if (patch != null) {
            allOperations.add(patch);
        }
        if (options != null) {
            allOperations.add(options);
        }

        return allOperations;
    }

    @JsonIgnore
    public Map<HttpMethod, SwaggerOperation> getOperationMap() {
        Map<HttpMethod, SwaggerOperation> result = new LinkedHashMap<HttpMethod, SwaggerOperation>();

        if (get != null) {
            result.put(HttpMethod.GET, get);
        }
        if (put != null) {
            result.put(HttpMethod.PUT, put);
        }
        if (post != null) {
            result.put(HttpMethod.POST, post);
        }
        if (delete != null) {
            result.put(HttpMethod.DELETE, delete);
        }
        if (patch != null) {
            result.put(HttpMethod.PATCH, patch);
        }
        if (head != null) {
            result.put(HttpMethod.HEAD, head);
        }
        if (options != null) {
            result.put(HttpMethod.OPTIONS, options);
        }

        return result;
    }

    public List<SwaggerParameter> getParameters() {
        return parameters;
    }

    public void setParameters(List<SwaggerParameter> parameters) {
        this.parameters = parameters;
    }

    public void addParameter(SwaggerParameter parameter) {
        if (this.parameters == null) {
            this.parameters = new ArrayList<SwaggerParameter>();
        }
        this.parameters.add(parameter);
    }

    @JsonIgnore
    public boolean isEmpty() {
        if (get == null && put == null && head == null && post == null && delete == null && patch == null && options == null) {
            return true;
        } else {
            return false;
        }
    }
}

