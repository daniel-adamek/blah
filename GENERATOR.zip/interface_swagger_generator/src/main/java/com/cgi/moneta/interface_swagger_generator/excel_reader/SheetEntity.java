package com.cgi.moneta.interface_swagger_generator.excel_reader;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SheetEntity {

    private String order;
    private String name;
    private String direction;
    private String type;
    private String description;

    public SheetEntity() {
    }

    public SheetEntity(String order, String name, String direction, String type, String description) {
        this.order = order;
        this.name = name;
        this.direction = direction;
        this.type = type;
        this.description = description;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}