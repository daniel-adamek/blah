package com.cgi.moneta.interface_swagger_generator;



import com.cgi.moneta.interface_swagger_generator.excel_reader.ExcelReader;
import com.cgi.moneta.interface_swagger_generator.excel_reader.SheetEntity;
import com.cgi.moneta.interface_swagger_generator.swagger.SwaggerBuilder;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;


public class App {
	static {
		setProperties();
	}

	public static Properties properties;

	public static void main(String[] args) {
			ExcelReader excelReader = new ExcelReader();
			SwaggerBuilder swaggerBuilder = new SwaggerBuilder();
			

			try {
				List<SheetEntity> sheetEntities = excelReader.getAllInterfacesFromExcel(properties.getProperty("XLSX_FILE_PATH"));
				swaggerBuilder.writeSwaggerSchemas(sheetEntities, properties.getProperty("SWAGGER_OUTPUT_PATH"));

			} catch (IOException e) {
				System.out.println("File not found " + e);
			} catch (InvalidFormatException e) {
				System.out.println("File invalid format " + e);
			}

	}

	private static void setProperties() {
		try {
			FileInputStream input = new FileInputStream("../interface_swagger_generator/app.properties");
			properties = new Properties();
			properties.load(input);
			input.close();
		} catch (FileNotFoundException e) {
			System.out.println("Properties file not found " + e);
		} catch (IOException e) {
			System.out.println("Properties IO exception " + e);
		}
	}
}
